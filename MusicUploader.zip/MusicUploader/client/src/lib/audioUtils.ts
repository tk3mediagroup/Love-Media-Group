import { SUPPORTED_AUDIO_FORMATS, MAX_FILE_SIZE } from "@shared/schema";

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

export function formatDuration(seconds: number): string {
  if (!seconds || isNaN(seconds)) return '0:00';
  
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  
  return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
}

export function validateAudioFile(file: File): { valid: boolean; error?: string } {
  // Check file type
  if (!SUPPORTED_AUDIO_FORMATS.includes(file.type)) {
    return {
      valid: false,
      error: `Unsupported file format. Please upload MP3, WAV, FLAC or OGG files only.`
    };
  }
  
  // Check file size
  if (file.size > MAX_FILE_SIZE) {
    return {
      valid: false,
      error: `File is too large. Maximum size is ${formatFileSize(MAX_FILE_SIZE)}.`
    };
  }
  
  return { valid: true };
}

export function getAudioFileDuration(file: File): Promise<number> {
  return new Promise((resolve, reject) => {
    const audio = new Audio();
    audio.preload = 'metadata';
    
    audio.onloadedmetadata = () => {
      resolve(audio.duration);
    };
    
    audio.onerror = () => {
      reject(new Error('Error loading audio metadata'));
    };
    
    audio.src = URL.createObjectURL(file);
  });
}

export function getBitRate(file: File, durationSeconds: number): number {
  // Approximate bit rate calculation: fileSize * 8 / duration
  return Math.round((file.size * 8) / (durationSeconds * 1000));
}

export function getFileType(fileName: string): string {
  const extension = fileName.split('.').pop()?.toLowerCase();
  return extension ? extension.toUpperCase() : 'Unknown';
}

// Function to generate random waveform data for visualization
export function generateWaveformData(numBars: number): number[] {
  const data: number[] = [];
  for (let i = 0; i < numBars; i++) {
    data.push(Math.random() * 100);
  }
  return data;
}
