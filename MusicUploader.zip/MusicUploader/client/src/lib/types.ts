export interface TrackMetadata {
  title: string;
  artist: string;
  genre: string;
  description?: string;
  visibility?: 'public' | 'private' | 'unlisted';
}

export interface UploadedFile {
  file: File;
  preview?: string;
  progress?: number;
  error?: string;
  uploaded?: boolean;
}

export interface AudioTrack {
  id: number;
  title: string;
  artist: string;
  genre: string;
  description?: string;
  fileName: string;
  fileSize: number;
  fileType: string;
  duration?: number; // in seconds
  bitRate?: number; // in kbps
  visibility: 'public' | 'private' | 'unlisted';
  uploadedAt: string;
}

export interface AudioPlayerState {
  isPlaying: boolean;
  currentTime: number; // in seconds
  duration: number; // in seconds
  progress: number; // percentage 0-100
}
