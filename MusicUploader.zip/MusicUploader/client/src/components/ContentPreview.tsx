import React, { useState, useEffect, useRef } from 'react';
import { Music, Video, Mic, RefreshCw, FileText } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import AudioPlayer from './AudioPlayer';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { formatDuration, formatFileSize } from '@/lib/audioUtils';
import { AudioTrack } from '@/lib/types';
import ReactPlayer from 'react-player';
import { useToast } from '@/hooks/use-toast';

interface ContentPreviewProps {
  uploadedSong: AudioTrack | null;
}

const ContentPreview: React.FC<ContentPreviewProps> = ({ uploadedSong }) => {
  const [visibility, setVisibility] = useState<string>('public');
  const [isPlaying, setIsPlaying] = useState(false);
  const [generatedContent, setGeneratedContent] = useState<{
    caption: string;
    videoUrl: string;
    audioNarration?: {
      narrationText: string;
      audioUrl: string;
    };
  } | null>(null);
  
  const [transcription, setTranscription] = useState<{
    transcription: string;
  } | null>(null);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const { toast } = useToast();
  
  useEffect(() => {
    // Set initial visibility from uploadedSong if available
    if (uploadedSong?.visibility) {
      setVisibility(uploadedSong.visibility);
    }

    // Generate content when a song is uploaded using the API
    if (uploadedSong) {
      // Indicate that we're generating content
      toast({
        title: "Generating content",
        description: "Please wait while we generate social media content for your track...",
      });
      
      // Call the API to generate content
      fetch(`/api/tracks/${uploadedSong.id}/generate-content`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to generate content');
        }
        return response.json();
      })
      .then(data => {
        setGeneratedContent({
          caption: data.caption,
          videoUrl: data.videoUrl,
        });
        
        toast({
          title: "Content generated",
          description: "Your social media content is ready!",
          variant: "default",
        });
      })
      .catch(error => {
        console.error('Error generating content:', error);
        
        // Fallback to a basic caption if API call fails
        setGeneratedContent({
          caption: `Check out this amazing ${uploadedSong.genre} track "${uploadedSong.title}" by ${uploadedSong.artist}! #music #${uploadedSong.genre} #newrelease`,
          videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' // Example video URL
        });
        
        toast({
          title: "AI Generation Error",
          description: "We couldn't connect to the AI service. Using a simple caption instead.",
          variant: "destructive",
        });
      });
    } else {
      setGeneratedContent(null);
    }
  }, [uploadedSong, toast]);

  const handlePlayStateChange = (playing: boolean) => {
    setIsPlaying(playing);
  };

  const audioSrc = uploadedSong ? `/uploads/${uploadedSong.fileName}` : undefined;

  return (
    <Card className="bg-white rounded-lg shadow-card">
      <CardContent className="p-6">
        <h2 className="text-xl font-semibold text-neutral-800 mb-6">Preview & Finalize</h2>
        
        {/* No content state */}
        {!uploadedSong && (
          <div className="py-12 flex flex-col items-center justify-center text-center">
            <div className="w-20 h-20 rounded-full bg-neutral-100 flex items-center justify-center mb-4">
              <Music className="h-10 w-10 text-neutral-400" />
            </div>
            <h3 className="text-lg font-medium text-neutral-700 mb-2">No track uploaded yet</h3>
            <p className="text-neutral-500 max-w-xs mx-auto">Your uploaded track will appear here for preview before publishing</p>
          </div>
        )}
        
        {/* Content preview state */}
        {uploadedSong && (
          <>
            {/* Track artwork and basic info */}
            <div className="flex flex-col md:flex-row items-center md:items-start gap-6 mb-8">
              <div className="w-40 h-40 bg-gradient-to-br from-primary-100 to-secondary-100 rounded-lg shadow-sm flex items-center justify-center">
                <Music className="h-16 w-16 text-neutral-400" />
              </div>
              
              <div className="flex-1 text-center md:text-left">
                <h3 className="text-xl font-semibold text-neutral-800 mb-2">
                  {uploadedSong.title}
                </h3>
                <p className="text-neutral-600 mb-4">
                  {uploadedSong.artist}
                </p>
                
                <div className="flex flex-wrap gap-2 justify-center md:justify-start mb-4">
                  <span className="px-3 py-1 bg-primary-50 text-primary-700 rounded-full text-sm font-medium">
                    {uploadedSong.genre.charAt(0).toUpperCase() + uploadedSong.genre.slice(1)}
                  </span>
                  <span className="px-3 py-1 bg-neutral-100 text-neutral-700 rounded-full text-sm font-medium">
                    {uploadedSong.duration 
                      ? formatDuration(uploadedSong.duration) 
                      : formatFileSize(uploadedSong.fileSize)}
                  </span>
                </div>
                
                <p className="text-sm text-neutral-600 mb-4">
                  {uploadedSong.description || "No description provided."}
                </p>
              </div>
            </div>
            
            {/* Audio player */}
            <AudioPlayer 
              audioSrc={audioSrc}
              onPlayStateChange={handlePlayStateChange}
            />
            
            {/* Transcription Section */}
            <div className="border-t border-neutral-200 pt-6 mt-6 mb-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-neutral-800">Audio Transcription & Analysis</h3>
                {!transcription && (
                  <Button 
                    variant="outline" 
                    className="flex items-center gap-2"
                    disabled={isTranscribing}
                    onClick={() => {
                      if (!uploadedSong) return;
                      
                      setIsTranscribing(true);
                      toast({
                        title: "Transcribing Audio",
                        description: "Please wait while we analyze and transcribe your audio track...",
                      });
                      
                      fetch(`/api/tracks/${uploadedSong.id}/transcribe`, {
                        method: 'POST',
                        headers: {
                          'Content-Type': 'application/json',
                        },
                        credentials: 'include',
                      })
                      .then(response => {
                        if (!response.ok) {
                          throw new Error('Failed to transcribe audio');
                        }
                        return response.json();
                      })
                      .then(data => {
                        setTranscription({
                          transcription: data.transcription,
                        });
                        
                        toast({
                          title: "Audio Transcription Complete",
                          description: "Your audio has been analyzed and transcribed!",
                          variant: "default",
                        });
                      })
                      .catch(error => {
                        console.error('Error transcribing audio:', error);
                        
                        toast({
                          title: "Premium Feature Required",
                          description: "Audio transcription requires a premium plan. Upgrade to gain access.",
                          variant: "destructive",
                        });
                        
                        // Suggest premium upgrade
                        setTimeout(() => {
                          if (confirm("Would you like to view our premium plans?")) {
                            window.location.href = "/pricing";
                          }
                        }, 1000);
                      })
                      .finally(() => {
                        setIsTranscribing(false);
                      });
                    }}
                  >
                    <FileText className="h-4 w-4" />
                    {isTranscribing ? "Transcribing..." : "Transcribe & Analyze"}
                  </Button>
                )}
              </div>
              
              {transcription ? (
                <div className="bg-neutral-50 rounded-lg p-4">
                  <div className="text-neutral-600 p-3 bg-white rounded border border-neutral-200 whitespace-pre-wrap">
                    {transcription.transcription}
                  </div>
                </div>
              ) : (
                <div className="bg-neutral-50 rounded-lg p-6 text-center">
                  <p className="text-neutral-600 mb-2">
                    Use AI to transcribe and analyze your audio content
                  </p>
                  <p className="text-sm text-neutral-500">
                    Get insights into themes, mood, and musical elements of your track
                  </p>
                </div>
              )}
            </div>
            
            {/* Generated Social Media Content */}
            {generatedContent && (
              <div className="border-t border-neutral-200 pt-6 mt-6 mb-6">
                <h3 className="text-lg font-medium text-neutral-800 mb-4">Generated Social Media Content</h3>
                
                <div className="bg-neutral-50 rounded-lg p-4 mb-6">
                  <h4 className="text-md font-medium text-neutral-700 mb-2">Caption</h4>
                  <p className="text-neutral-600 mb-4 p-3 bg-white rounded border border-neutral-200">
                    {generatedContent.caption}
                  </p>
                  
                  <h4 className="text-md font-medium text-neutral-700 mb-2">Video Preview</h4>
                  <div className="aspect-video rounded-lg overflow-hidden border border-neutral-200 bg-black">
                    <ReactPlayer 
                      url={generatedContent.videoUrl} 
                      controls
                      width="100%"
                      height="100%"
                    />
                  </div>
                </div>
                
                {/* Audio Narration Section */}
                {generatedContent.audioNarration ? (
                  <div className="bg-neutral-50 rounded-lg p-4 mb-6">
                    <h4 className="text-md font-medium text-neutral-700 mb-2">Audio Narration</h4>
                    <p className="text-neutral-600 mb-4 p-3 bg-white rounded border border-neutral-200">
                      {generatedContent.audioNarration.narrationText}
                    </p>
                    
                    <div className="mt-2">
                      <audio 
                        src={generatedContent.audioNarration.audioUrl} 
                        controls 
                        className="w-full" 
                      />
                    </div>
                  </div>
                ) : (
                  <div className="mb-4">
                    <Button 
                      variant="outline" 
                      className="flex items-center gap-2"
                      onClick={() => {
                        if (!uploadedSong) return;
                        
                        toast({
                          title: "Generating Audio Narration",
                          description: "Please wait while we create an audio narration for your track...",
                        });
                        
                        fetch(`/api/tracks/${uploadedSong.id}/generate-narration`, {
                          method: 'POST',
                          headers: {
                            'Content-Type': 'application/json',
                          },
                          credentials: 'include',
                        })
                        .then(response => {
                          if (!response.ok) {
                            throw new Error('Failed to generate audio narration');
                          }
                          return response.json();
                        })
                        .then(data => {
                          setGeneratedContent(prevContent => ({
                            ...prevContent!,
                            audioNarration: {
                              narrationText: data.narrationText,
                              audioUrl: data.audioUrl
                            }
                          }));
                          
                          toast({
                            title: "Audio Narration Generated",
                            description: "Your audio narration is ready to play!",
                            variant: "default",
                          });
                        })
                        .catch(error => {
                          console.error('Error generating audio narration:', error);
                          
                          toast({
                            title: "Premium Feature Required",
                            description: "Audio narration requires a premium plan. Upgrade to gain access.",
                            variant: "destructive",
                          });
                          
                          // Suggest premium upgrade
                          setTimeout(() => {
                            if (confirm("Would you like to view our premium plans?")) {
                              window.location.href = "/pricing";
                            }
                          }, 1000);
                        });
                      }}
                    >
                      <Mic className="h-4 w-4" />
                      Generate Audio Narration
                    </Button>
                  </div>
                )}
                
                <div className="flex flex-col sm:flex-row gap-3 mb-6">
                  <Button className="px-4 py-2 text-white rounded-md bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 transition-colors duration-200 flex-1">
                    Share to Social Media
                  </Button>
                  <Button 
                    variant="outline" 
                    className="px-4 py-2 border border-neutral-300 text-neutral-700 rounded-md hover:bg-neutral-50 transition-colors duration-200 flex items-center justify-center gap-2"
                    onClick={() => {
                      if (!uploadedSong) return;
                      
                      toast({
                        title: "Regenerating Content",
                        description: "Please wait while we regenerate content for your track...",
                      });
                      
                      fetch(`/api/tracks/${uploadedSong.id}/generate-content`, {
                        method: 'POST',
                        headers: {
                          'Content-Type': 'application/json',
                        },
                        credentials: 'include',
                      })
                      .then(response => {
                        if (!response.ok) {
                          throw new Error('Failed to regenerate content');
                        }
                        return response.json();
                      })
                      .then(data => {
                        setGeneratedContent({
                          caption: data.caption,
                          videoUrl: data.videoUrl,
                        });
                        
                        toast({
                          title: "Content Regenerated",
                          description: "Your social media content has been updated!",
                          variant: "default",
                        });
                      })
                      .catch(error => {
                        console.error('Error regenerating content:', error);
                        
                        toast({
                          title: "Premium Feature Required",
                          description: "Content regeneration requires a premium plan. Upgrade to gain access.",
                          variant: "destructive",
                        });
                        
                        // Suggest premium upgrade
                        setTimeout(() => {
                          if (confirm("Would you like to view our premium plans?")) {
                            window.location.href = "/pricing";
                          }
                        }, 1000);
                      });
                    }}
                  >
                    <RefreshCw className="h-4 w-4" />
                    Regenerate Content
                  </Button>
                </div>
              </div>
            )}
            
            {/* Publishing options */}
            <div className="border-t border-neutral-200 pt-6">
              <h3 className="text-lg font-medium text-neutral-800 mb-4">Publishing Options</h3>
              
              <RadioGroup 
                value={visibility} 
                onValueChange={setVisibility}
                className="space-y-3 mb-6"
              >
                <div className="flex items-center">
                  <RadioGroupItem value="public" id="visibility-public" />
                  <Label htmlFor="visibility-public" className="ml-3">
                    <span className="block text-sm font-medium text-neutral-700">Public</span>
                    <span className="block text-xs text-neutral-500">Anyone can listen to this track</span>
                  </Label>
                </div>
                
                <div className="flex items-center">
                  <RadioGroupItem value="private" id="visibility-private" />
                  <Label htmlFor="visibility-private" className="ml-3">
                    <span className="block text-sm font-medium text-neutral-700">Private</span>
                    <span className="block text-xs text-neutral-500">Only you can access this track</span>
                  </Label>
                </div>
                
                <div className="flex items-center">
                  <RadioGroupItem value="unlisted" id="visibility-unlisted" />
                  <Label htmlFor="visibility-unlisted" className="ml-3">
                    <span className="block text-sm font-medium text-neutral-700">Unlisted</span>
                    <span className="block text-xs text-neutral-500">Anyone with the link can listen</span>
                  </Label>
                </div>
              </RadioGroup>
              
              <div className="flex flex-col sm:flex-row gap-3">
                <Button className="px-4 py-2 bg-primary-500 text-white rounded-md hover:bg-primary-600 transition-colors duration-200 flex-1">
                  Publish Track
                </Button>
                <Button variant="outline" className="px-4 py-2 border border-neutral-300 text-neutral-700 rounded-md hover:bg-neutral-50 transition-colors duration-200">
                  Save Draft
                </Button>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default ContentPreview;
