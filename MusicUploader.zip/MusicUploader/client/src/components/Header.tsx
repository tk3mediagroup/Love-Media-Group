import React from 'react';
import { Link } from 'wouter';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 md:py-6 flex justify-between items-center">
        <div className="flex items-center">
          <div className="h-10 w-10 mr-3">
            <img src="/love-media-logo.png" alt="Love Media Group Logo" className="h-full w-full object-contain" />
          </div>
          <h1 className="text-xl md:text-2xl font-bold text-neutral-800">Love Media Group</h1>
        </div>
        <nav>
          <ul className="flex space-x-4">
            <li>
              <Link href="/">
                <a className="text-neutral-600 hover:text-primary-500 transition-colors duration-200">Home</a>
              </Link>
            </li>
            <li>
              <Link href="/library">
                <a className="text-neutral-600 hover:text-primary-500 transition-colors duration-200">Library</a>
              </Link>
            </li>
            <li>
              <Link href="/pricing">
                <a className="text-neutral-600 hover:text-primary-500 transition-colors duration-200">Pricing</a>
              </Link>
            </li>
            <li>
              <Link href="/upload">
                <a className="text-primary-500 font-medium">Upload</a>
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;
