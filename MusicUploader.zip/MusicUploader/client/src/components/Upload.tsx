import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Upload as UploadIcon, AlertCircle, Lock, UserPlus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { apiRequest, getQueryFn } from '@/lib/queryClient';
import { validateAudioFile, formatFileSize, formatDuration, getFileType } from '@/lib/audioUtils';
import { UploadedFile, TrackMetadata, AudioTrack } from '@/lib/types';
import { queryClient } from '@/lib/queryClient';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';

interface UploadProps {
  setUploadedSong: (song: AudioTrack | null) => void;
}

const Upload: React.FC<UploadProps> = ({ setUploadedSong }) => {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<UploadedFile | null>(null);
  const [metadata, setMetadata] = useState<TrackMetadata>({
    title: '',
    artist: '',
    genre: '',
    description: '',
    visibility: 'public'
  });
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [, setLocation] = useLocation();
  
  // Check if user is authenticated
  const { data: user, isLoading: isUserLoading, error: userError } = useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: getQueryFn<any>({ on401: 'returnNull' })
  });

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback(() => {
    setIsDragging(false);
  }, []);

  const handleFileDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileSelection(e.dataTransfer.files[0]);
    }
  }, []);

  const handleFileInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFileSelection(e.target.files[0]);
    }
  }, []);

  const handleFileSelection = useCallback((file: File) => {
    // Validate file
    const validation = validateAudioFile(file);
    if (!validation.valid) {
      toast({
        title: "Invalid File",
        description: validation.error,
        variant: "destructive"
      });
      return;
    }

    // Set file in state
    setUploadedFile({
      file,
      progress: 0
    });

    // Try to extract title and artist from filename
    const fileName = file.name.replace(/\.[^/.]+$/, ""); // Remove extension
    const parts = fileName.split(" - ");
    
    if (parts.length > 1) {
      setMetadata(prev => ({
        ...prev,
        artist: parts[0],
        title: parts.slice(1).join(" - ")
      }));
    } else {
      setMetadata(prev => ({
        ...prev,
        title: fileName
      }));
    }
  }, [toast]);

  const handleUpload = useCallback(async () => {
    if (!uploadedFile) {
      toast({
        title: "No File Selected",
        description: "Please select an audio file to upload",
        variant: "destructive"
      });
      return;
    }

    if (!metadata.title || !metadata.artist || !metadata.genre) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    setIsUploading(true);
    
    try {
      // Create form data
      const formData = new FormData();
      formData.append('audioFile', uploadedFile.file);
      formData.append('title', metadata.title);
      formData.append('artist', metadata.artist);
      formData.append('genre', metadata.genre);
      formData.append('description', metadata.description || '');
      formData.append('visibility', metadata.visibility || 'public');
      
      // Mock upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          const newProgress = prev + Math.random() * 15;
          return newProgress < 95 ? newProgress : 95;
        });
      }, 300);

      // Upload the file
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include'
      });

      clearInterval(progressInterval);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Upload failed');
      }

      // Complete progress
      setUploadProgress(100);
      
      // Get the uploaded track data from response
      const uploadedTrack: AudioTrack = await response.json();
      
      // Update UI states
      setUploadedFile(prev => prev ? { ...prev, uploaded: true } : null);
      
      // Update parent component
      setUploadedSong(uploadedTrack);
      
      // Show success message
      toast({
        title: "Upload Successful",
        description: "Your track has been uploaded successfully!",
        variant: "default"
      });
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/tracks'] });
      
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: "Upload Failed",
        description: error instanceof Error ? error.message : "An unexpected error occurred",
        variant: "destructive"
      });
      
      setUploadedFile(prev => prev ? { 
        ...prev, 
        error: error instanceof Error ? error.message : "Upload failed" 
      } : null);
    } finally {
      setIsUploading(false);
    }
  }, [uploadedFile, metadata, toast, setUploadedSong]);

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setMetadata(prev => ({ ...prev, [name]: value }));
  }, []);

  const handleSelectChange = useCallback((value: string, name: string) => {
    setMetadata(prev => ({ ...prev, [name]: value }));
  }, []);

  // Add a function to redirect to login
  const redirectToLogin = useCallback(() => {
    setLocation('/login');
  }, [setLocation]);

  // If we're loading the user status, show a loading state
  if (isUserLoading) {
    return (
      <Card className="bg-white rounded-lg shadow-card">
        <CardContent className="p-6 flex flex-col items-center justify-center py-12">
          <div className="animate-pulse w-24 h-24 rounded-full bg-neutral-200 mb-6"></div>
          <h2 className="text-xl font-semibold text-neutral-800 mb-2">Checking authentication...</h2>
          <p className="text-neutral-500 text-center">Please wait while we verify your account.</p>
        </CardContent>
      </Card>
    );
  }

  // If the user is not authenticated, show login prompt
  if (!user) {
    return (
      <Card className="bg-white rounded-lg shadow-card">
        <CardContent className="p-6 flex flex-col items-center justify-center py-12">
          <div className="w-24 h-24 rounded-full bg-neutral-100 flex items-center justify-center mb-6">
            <Lock className="h-12 w-12 text-neutral-400" />
          </div>
          <h2 className="text-xl font-semibold text-neutral-800 mb-2">Authentication Required</h2>
          <p className="text-neutral-500 text-center mb-8 max-w-md">
            You need to be logged in to upload tracks and generate social media content.
          </p>
          <div className="flex gap-4">
            <Button onClick={redirectToLogin} className="bg-primary-500 hover:bg-primary-600">
              Log In
            </Button>
            <Button onClick={() => setLocation('/register')} variant="outline" className="border-neutral-300">
              <UserPlus className="mr-2 h-4 w-4" />
              Create Account
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // If user is authenticated, show the upload form
  return (
    <Card className="bg-white rounded-lg shadow-card">
      <CardContent className="p-6">
        <h2 className="text-xl font-semibold text-neutral-800 mb-4">Upload Your Track</h2>
        
        {!uploadedFile || !uploadedFile.uploaded ? (
          <div 
            className={`drop-zone p-8 mb-4 rounded-lg flex flex-col items-center justify-center text-center ${isDragging ? 'active border-primary-500 bg-primary-50 bg-opacity-5' : 'border-2 border-dashed border-primary-200'}`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleFileDrop}
            onClick={() => fileInputRef.current?.click()}
          >
            <div className="mb-4 w-16 h-16 rounded-full bg-primary-50 flex items-center justify-center">
              <UploadIcon className="h-8 w-8 text-primary-500" />
            </div>
            <p className="text-lg font-medium text-neutral-700 mb-1">Drag and drop your audio file here</p>
            <p className="text-neutral-500 mb-4">or click to browse your files</p>
            
            <Button className="px-4 py-2 bg-primary-500 text-white rounded-md hover:bg-primary-600 transition-colors duration-200">
              Choose File
            </Button>
            
            <input 
              type="file" 
              ref={fileInputRef}
              className="hidden" 
              accept="audio/*" 
              onChange={handleFileInputChange}
            />
            
            <div className="mt-4 text-sm text-neutral-500">
              <p>Supported formats: MP3, WAV, FLAC, OGG</p>
              <p>Maximum file size: 50MB</p>
            </div>
          </div>
        ) : null}
        
        {/* Upload progress */}
        {isUploading && (
          <div className="mt-6">
            <div className="flex justify-between mb-2">
              <span className="text-sm font-medium text-neutral-700">
                {uploadedFile?.file.name}
              </span>
              <span className="text-sm text-neutral-600">
                {Math.round(uploadProgress)}%
              </span>
            </div>
            <Progress value={uploadProgress} className="w-full h-2.5 bg-neutral-200" />
          </div>
        )}
        
        {/* File details after upload */}
        {uploadedFile && uploadedFile.uploaded && (
          <div className="mt-6 p-4 border border-neutral-200 rounded-lg">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-medium text-neutral-800">{uploadedFile.file.name}</h3>
              <span className="px-2 py-1 bg-green-500 bg-opacity-10 text-green-600 rounded text-xs font-medium">Uploaded</span>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-neutral-500 mb-1">File Size</p>
                <p className="text-neutral-800 font-medium">{formatFileSize(uploadedFile.file.size)}</p>
              </div>
              <div>
                <p className="text-neutral-500 mb-1">Format</p>
                <p className="text-neutral-800 font-medium">{getFileType(uploadedFile.file.name)}</p>
              </div>
            </div>
          </div>
        )}
        
        {/* Error state */}
        {uploadedFile?.error && (
          <div className="mt-4 p-3 bg-red-50 text-red-500 rounded-md flex items-start">
            <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" />
            <span>{uploadedFile.error}</span>
          </div>
        )}
        
        {/* Form for track metadata */}
        <div className="mt-8">
          <h3 className="text-lg font-medium text-neutral-800 mb-4">Track Details</h3>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="title" className="block text-sm font-medium text-neutral-700 mb-1">
                Track Title
              </Label>
              <Input
                id="title"
                name="title"
                value={metadata.title}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                placeholder="Enter track title"
              />
            </div>
            
            <div>
              <Label htmlFor="artist" className="block text-sm font-medium text-neutral-700 mb-1">
                Artist Name
              </Label>
              <Input
                id="artist"
                name="artist"
                value={metadata.artist}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                placeholder="Enter artist name"
              />
            </div>
            
            <div>
              <Label htmlFor="genre" className="block text-sm font-medium text-neutral-700 mb-1">
                Genre
              </Label>
              <Select 
                value={metadata.genre} 
                onValueChange={(value) => handleSelectChange(value, 'genre')}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select a genre" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pop">Pop</SelectItem>
                  <SelectItem value="rock">Rock</SelectItem>
                  <SelectItem value="hiphop">Hip Hop</SelectItem>
                  <SelectItem value="rnb">R&B</SelectItem>
                  <SelectItem value="electronic">Electronic</SelectItem>
                  <SelectItem value="jazz">Jazz</SelectItem>
                  <SelectItem value="classical">Classical</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="description" className="block text-sm font-medium text-neutral-700 mb-1">
                Description
              </Label>
              <Textarea
                id="description"
                name="description"
                value={metadata.description}
                onChange={handleInputChange}
                rows={3}
                className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                placeholder="Add a description for your track"
              />
            </div>

            <div className="pt-4">
              <Button
                onClick={handleUpload}
                disabled={isUploading || !uploadedFile || !metadata.title || !metadata.artist || !metadata.genre}
                className="w-full bg-primary-500 hover:bg-primary-600"
              >
                {isUploading ? "Uploading..." : uploadedFile?.uploaded ? "Upload Another Track" : "Upload Track"}
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default Upload;
