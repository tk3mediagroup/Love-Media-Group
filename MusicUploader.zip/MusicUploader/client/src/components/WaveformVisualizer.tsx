import React, { useEffect, useState } from 'react';
import { generateWaveformData } from '@/lib/audioUtils';

interface WaveformVisualizerProps {
  progress: number; // 0-100 percentage
  isPlaying: boolean;
  audioRef?: React.RefObject<HTMLAudioElement>;
}

const WaveformVisualizer: React.FC<WaveformVisualizerProps> = ({ 
  progress, 
  isPlaying,
  audioRef
}) => {
  const [waveformData, setWaveformData] = useState<number[]>([]);
  const barCount = 100;

  useEffect(() => {
    // Generate random waveform data on component mount
    setWaveformData(generateWaveformData(barCount));
  }, []);

  return (
    <div className="waveform mb-3 h-[60px] w-full relative bg-neutral-100 rounded-md overflow-hidden">
      <div 
        className="waveform-progress absolute h-full bg-primary-500 bg-opacity-20 transition-width"
        style={{ width: `${progress}%` }}
      />
      <div className="waveform-bars flex items-center h-full px-2 gap-[2px]">
        {waveformData.map((height, index) => (
          <div
            key={index}
            className="waveform-bar w-[3px] rounded-[1px] bg-primary-500 opacity-70"
            style={{ 
              height: `${height}%`,
              opacity: progress > (index / barCount) * 100 ? 0.9 : 0.5 
            }}
          />
        ))}
      </div>
    </div>
  );
};

export default WaveformVisualizer;
