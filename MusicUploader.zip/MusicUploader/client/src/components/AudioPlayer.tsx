import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, SkipBack, SkipForward } from 'lucide-react';
import { formatDuration } from '@/lib/audioUtils';
import WaveformVisualizer from './WaveformVisualizer';
import { AudioPlayerState } from '@/lib/types';

interface AudioPlayerProps {
  audioSrc?: string;
  onPlayStateChange?: (isPlaying: boolean) => void;
}

const AudioPlayer: React.FC<AudioPlayerProps> = ({ 
  audioSrc, 
  onPlayStateChange 
}) => {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [playerState, setPlayerState] = useState<AudioPlayerState>({
    isPlaying: false,
    currentTime: 0,
    duration: 0,
    progress: 0
  });

  useEffect(() => {
    // Reset player state when audio source changes
    if (audioSrc) {
      setPlayerState({
        isPlaying: false,
        currentTime: 0,
        duration: 0,
        progress: 0
      });
    }
  }, [audioSrc]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => {
      const currentTime = audio.currentTime;
      const duration = audio.duration || 0;
      const progress = duration > 0 ? (currentTime / duration) * 100 : 0;
      
      setPlayerState(prevState => ({
        ...prevState,
        currentTime,
        progress
      }));
    };

    const handleLoadedMetadata = () => {
      setPlayerState(prevState => ({
        ...prevState,
        duration: audio.duration || 0
      }));
    };

    const handleEnded = () => {
      setPlayerState(prevState => ({
        ...prevState,
        isPlaying: false,
        currentTime: 0,
        progress: 0
      }));
      if (onPlayStateChange) onPlayStateChange(false);
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('ended', handleEnded);
    };
  }, [onPlayStateChange]);

  const togglePlayPause = () => {
    const audio = audioRef.current;
    if (!audio || !audioSrc) return;

    if (playerState.isPlaying) {
      audio.pause();
    } else {
      audio.play();
    }

    setPlayerState(prevState => ({
      ...prevState,
      isPlaying: !prevState.isPlaying
    }));

    if (onPlayStateChange) {
      onPlayStateChange(!playerState.isPlaying);
    }
  };

  const handleWaveformClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const audio = audioRef.current;
    if (!audio || !audioSrc) return;

    const waveform = e.currentTarget;
    const bounds = waveform.getBoundingClientRect();
    const x = e.clientX - bounds.left;
    const percentage = (x / bounds.width) * 100;
    const newTime = (percentage / 100) * playerState.duration;

    audio.currentTime = newTime;
    setPlayerState(prevState => ({
      ...prevState,
      currentTime: newTime,
      progress: percentage
    }));
  };

  const skipBackward = () => {
    const audio = audioRef.current;
    if (!audio || !audioSrc) return;

    const newTime = Math.max(0, audio.currentTime - 10);
    audio.currentTime = newTime;
  };

  const skipForward = () => {
    const audio = audioRef.current;
    if (!audio || !audioSrc) return;

    const newTime = Math.min(audio.duration, audio.currentTime + 10);
    audio.currentTime = newTime;
  };

  return (
    <div className="audio-player w-full mb-8">
      {audioSrc && (
        <audio ref={audioRef} src={audioSrc} preload="metadata">
          Your browser does not support the audio element.
        </audio>
      )}

      <div 
        className="waveform-container cursor-pointer" 
        onClick={handleWaveformClick}
      >
        <WaveformVisualizer 
          progress={playerState.progress} 
          isPlaying={playerState.isPlaying}
          audioRef={audioRef}
        />
      </div>

      <div className="flex justify-between items-center text-sm text-neutral-500 mb-4">
        <span>{formatDuration(playerState.currentTime)}</span>
        <span>{formatDuration(playerState.duration)}</span>
      </div>

      <div className="player-controls flex items-center justify-center gap-4">
        <button
          className="control-button w-10 h-10 rounded-full bg-primary-500 text-white flex items-center justify-center hover:bg-primary-600 transition-colors"
          onClick={skipBackward}
          disabled={!audioSrc}
          aria-label="Previous"
        >
          <SkipBack className="h-5 w-5" />
        </button>

        <button
          className="control-button w-12 h-12 rounded-full bg-primary-500 text-white flex items-center justify-center hover:bg-primary-600 transition-colors"
          onClick={togglePlayPause}
          disabled={!audioSrc}
          aria-label={playerState.isPlaying ? "Pause" : "Play"}
        >
          {playerState.isPlaying ? (
            <Pause className="h-6 w-6" />
          ) : (
            <Play className="h-6 w-6" />
          )}
        </button>

        <button
          className="control-button w-10 h-10 rounded-full bg-primary-500 text-white flex items-center justify-center hover:bg-primary-600 transition-colors"
          onClick={skipForward}
          disabled={!audioSrc}
          aria-label="Next"
        >
          <SkipForward className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
};

export default AudioPlayer;
