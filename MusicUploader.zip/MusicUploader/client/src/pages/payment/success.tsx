import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { CheckCircle2 } from 'lucide-react';

export default function PaymentSuccessPage() {
  const { toast } = useToast();
  const [sessionId, setSessionId] = useState<string | null>(null);

  useEffect(() => {
    // Extract the session ID from the URL query parameters
    const params = new URLSearchParams(window.location.search);
    const session = params.get('session_id');
    setSessionId(session);

    // Show welcome toast
    toast({
      title: "Payment Successful!",
      description: "Thank you for your purchase. Your premium features are now activated.",
      variant: "default",
    });
  }, [toast]);

  return (
    <div className="container max-w-4xl mx-auto px-4 py-12">
      <Card className="border-2 border-green-100 shadow-xl">
        <CardHeader className="pb-4 text-center">
          <div className="mx-auto mb-4">
            <CheckCircle2 className="h-16 w-16 text-green-500" />
          </div>
          <CardTitle className="text-3xl font-bold text-green-800">Payment Successful!</CardTitle>
          <CardDescription className="text-lg">
            Thank you for upgrading your Love Media Group experience
          </CardDescription>
        </CardHeader>

        <CardContent className="text-center pb-6">
          <p className="text-neutral-700 mb-4">
            Your purchase has been completed successfully and your account has been upgraded.
            You now have access to premium features.
          </p>

          {sessionId && (
            <div className="text-sm text-neutral-500 bg-neutral-50 p-3 rounded border border-neutral-200 inline-block">
              Transaction ID: {sessionId}
            </div>
          )}
        </CardContent>

        <CardFooter className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild>
            <Link href="/">Return to Dashboard</Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/pricing">View Other Plans</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}