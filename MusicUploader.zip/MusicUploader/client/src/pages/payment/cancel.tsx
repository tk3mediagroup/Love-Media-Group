import React, { useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { XCircle } from 'lucide-react';

export default function PaymentCancelPage() {
  const { toast } = useToast();

  useEffect(() => {
    // Show notification toast
    toast({
      title: "Payment Cancelled",
      description: "Your payment process was cancelled. No charges were made.",
      variant: "default",
    });
  }, [toast]);

  return (
    <div className="container max-w-4xl mx-auto px-4 py-12">
      <Card className="border-2 border-neutral-200 shadow-lg">
        <CardHeader className="pb-4 text-center">
          <div className="mx-auto mb-4">
            <XCircle className="h-16 w-16 text-neutral-500" />
          </div>
          <CardTitle className="text-3xl font-bold text-neutral-800">Payment Cancelled</CardTitle>
          <CardDescription className="text-lg">
            Your payment process was cancelled
          </CardDescription>
        </CardHeader>

        <CardContent className="text-center pb-6">
          <p className="text-neutral-700 mb-4">
            No worries! Your payment was cancelled and no charges were made to your account.
            You can try again whenever you're ready.
          </p>
        </CardContent>

        <CardFooter className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild>
            <Link href="/pricing">Return to Pricing</Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/">Go to Dashboard</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}