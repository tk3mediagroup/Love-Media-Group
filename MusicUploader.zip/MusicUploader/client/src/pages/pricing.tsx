import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Check } from 'lucide-react';

export default function PricingPage() {
  const { toast } = useToast();

  const handlePurchase = async (productId: string) => {
    try {
      toast({
        title: "Processing...",
        description: "Setting up your checkout session",
      });

      const response = await apiRequest('POST', '/api/create-checkout-session', { productId });
      const data = await response.json();

      // Redirect to Stripe checkout
      window.location.href = data.url;
    } catch (error) {
      console.error('Checkout error:', error);
      toast({
        title: "Checkout Error",
        description: "Could not initiate checkout. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container mx-auto py-12 px-4">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-neutral-800 mb-4">
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary-500 to-secondary-500">
            AI Content Plans
          </span>
        </h1>
        <p className="text-xl text-neutral-600 max-w-3xl mx-auto">
          Choose your AI-powered content generation package with automatic social media posting, user collaboration, and file sharing capabilities
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
        {/* Basic AI Tier Card */}
        <Card className="border-2 border-neutral-200 shadow-lg transition-all hover:shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0">
            <div className="bg-neutral-200 text-neutral-800 text-xs font-semibold py-1 px-3 rotate-45 transform translate-x-6 -translate-y-2">
              FREE
            </div>
          </div>
          <CardHeader className="pb-4">
            <CardTitle className="text-2xl font-bold text-neutral-800">Basic AI</CardTitle>
            <CardDescription className="text-lg">
              Simple AI-generated content for your audio
            </CardDescription>
            <div className="mt-4 flex items-baseline">
              <span className="text-3xl font-bold text-neutral-600">$0</span>
              <span className="ml-1 text-lg text-neutral-500">/forever</span>
            </div>
          </CardHeader>

          <CardContent className="pb-4">
            <ul className="space-y-3">
              {[
                "Basic AI caption generation",
                "5 AI content generations per month",
                "Auto-post to 1 social platform",
                "Basic post scheduling",
                "Share content with 1 collaborator",
                "100MB file storage"
              ].map((feature, index) => (
                <li key={index} className="flex items-start">
                  <Check className="h-5 w-5 text-neutral-500 mr-2 shrink-0 mt-0.5" />
                  <span className="text-neutral-700">{feature}</span>
                </li>
              ))}
            </ul>
          </CardContent>

          <CardFooter>
            <Button 
              className="w-full bg-neutral-100 text-neutral-800 border-neutral-300 hover:bg-neutral-200" 
              variant="outline"
            >
              Current Plan
            </Button>
          </CardFooter>
        </Card>

        {/* Standard AI Content Generation Card */}
        <Card className="border-2 border-primary-100 shadow-lg transition-all hover:shadow-xl scale-105 z-10">
          <div className="absolute -top-4 left-0 right-0 text-center">
            <span className="bg-primary-500 text-white text-sm font-bold py-1 px-4 rounded-full">
              Most Popular
            </span>
          </div>
          <CardHeader className="pb-4">
            <CardTitle className="text-2xl font-bold text-primary-800">Standard AI</CardTitle>
            <CardDescription className="text-lg">
              Professional AI content generation
            </CardDescription>
            <div className="mt-4 flex items-baseline">
              <span className="text-3xl font-bold text-primary-600">$19.99</span>
              <span className="ml-1 text-lg text-primary-500">/month</span>
            </div>
          </CardHeader>

          <CardContent className="pb-4">
            <ul className="space-y-3">
              {[
                "Everything in Basic AI tier",
                "Enhanced caption creation",
                "Auto-post to 3 social platforms",
                "Smart scheduling for optimal posting",
                "Team collaboration (up to 5 users)",
                "5GB shared file storage",
                "30 AI generations per month"
              ].map((feature, index) => (
                <li key={index} className="flex items-start">
                  <Check className="h-5 w-5 text-primary-500 mr-2 shrink-0 mt-0.5" />
                  <span className="text-neutral-700">{feature}</span>
                </li>
              ))}
            </ul>
          </CardContent>

          <CardFooter>
            <Button 
              className="w-full bg-gradient-to-r from-primary-500 to-primary-600 hover:from-primary-600 hover:to-primary-700" 
              onClick={() => handlePurchase('standard-ai-content')}
            >
              Upgrade to Standard AI
            </Button>
          </CardFooter>
        </Card>

        {/* Premium AI Content Generation Card */}
        <Card className="border-2 border-secondary-100 shadow-lg transition-all hover:shadow-xl">
          <CardHeader className="pb-4">
            <CardTitle className="text-2xl font-bold text-secondary-800">Premium AI</CardTitle>
            <CardDescription className="text-lg">
              Enterprise-grade AI content generation
            </CardDescription>
            <div className="mt-4 flex items-baseline">
              <span className="text-3xl font-bold text-secondary-600">$29.99</span>
              <span className="ml-1 text-lg text-secondary-500">/month</span>
            </div>
          </CardHeader>

          <CardContent className="pb-4">
            <ul className="space-y-3">
              {[
                "Everything in Standard AI tier",
                "Unlimited AI content generations",
                "Auto-post to unlimited platforms",
                "Enterprise team collaboration",
                "50GB shared file storage",
                "Real-time collaboration workspace",
                "Role-based access controls"
              ].map((feature, index) => (
                <li key={index} className="flex items-start">
                  <Check className="h-5 w-5 text-secondary-500 mr-2 shrink-0 mt-0.5" />
                  <span className="text-neutral-700">{feature}</span>
                </li>
              ))}
            </ul>
          </CardContent>

          <CardFooter>
            <Button 
              className="w-full bg-gradient-to-r from-secondary-500 to-secondary-600 hover:from-secondary-600 hover:to-secondary-700" 
              onClick={() => handlePurchase('premium-ai-content')}
            >
              Get Premium AI
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}