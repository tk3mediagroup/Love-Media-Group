import React, { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Upload from '@/components/Upload';
import ContentPreview from '@/components/ContentPreview';
import { AudioTrack } from '@/lib/types';

const Home: React.FC = () => {
  const [uploadedSong, setUploadedSong] = useState<AudioTrack | null>(null);

  return (
    <div className="min-h-screen bg-neutral-50 flex flex-col">
      <Header />
      
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Upload setUploadedSong={setUploadedSong} />
          <ContentPreview uploadedSong={uploadedSong} />
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Home;
