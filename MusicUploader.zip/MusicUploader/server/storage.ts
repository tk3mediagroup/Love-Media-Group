import { tracks, type Track, type InsertTrack, users, type User, type InsertUser } from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

// Modify the interface with CRUD methods
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Track operations
  createTrack(track: InsertTrack): Promise<Track>;
  getTrack(id: number): Promise<Track | undefined>;
  getAllTracks(): Promise<Track[]>;
  getTracksByUser(username: string): Promise<Track[]>;
  getTracksByUserId(userId: number): Promise<Track[]>;
  deleteTrack(id: number): Promise<boolean>;
  updateTrack(id: number, track: Partial<InsertTrack>): Promise<Track | undefined>;
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const userWithTimestamp = {
      ...insertUser,
      createdAt: new Date()
    };
    const result = await db.insert(users).values(userWithTimestamp).returning();
    return result[0];
  }

  // Track operations
  async createTrack(insertTrack: InsertTrack): Promise<Track> {
    const trackWithTimestamp = {
      ...insertTrack,
      uploadedAt: new Date(),
      // Ensure required fields have appropriate default values
      description: insertTrack.description ?? null,
      duration: insertTrack.duration ?? null,
      bitRate: insertTrack.bitRate ?? null,
      userId: insertTrack.userId ?? null,
      visibility: insertTrack.visibility ?? 'public'
    };
    const result = await db.insert(tracks).values(trackWithTimestamp).returning();
    return result[0];
  }

  async getTrack(id: number): Promise<Track | undefined> {
    const result = await db.select().from(tracks).where(eq(tracks.id, id));
    return result[0];
  }

  async getAllTracks(): Promise<Track[]> {
    return await db.select().from(tracks);
  }

  async getTracksByUser(username: string): Promise<Track[]> {
    const user = await this.getUserByUsername(username);
    if (!user) return [];
    
    return await db.select().from(tracks).where(eq(tracks.userId, user.id));
  }
  
  async getTracksByUserId(userId: number): Promise<Track[]> {
    return await db.select().from(tracks).where(eq(tracks.userId, userId));
  }

  async deleteTrack(id: number): Promise<boolean> {
    const result = await db.delete(tracks).where(eq(tracks.id, id)).returning();
    return result.length > 0;
  }

  async updateTrack(id: number, updateData: Partial<InsertTrack>): Promise<Track | undefined> {
    const result = await db
      .update(tracks)
      .set(updateData)
      .where(eq(tracks.id, id))
      .returning();
    
    return result[0];
  }
}

// Memory storage implementation - kept for reference
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private tracks: Map<number, Track>;
  private userIdCounter: number;
  private trackIdCounter: number;

  constructor() {
    this.users = new Map();
    this.tracks = new Map();
    this.userIdCounter = 1;
    this.trackIdCounter = 1;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  // Track operations
  async createTrack(insertTrack: InsertTrack): Promise<Track> {
    const id = this.trackIdCounter++;
    const track: Track = { 
      ...insertTrack, 
      id,
      uploadedAt: new Date(),
      // Ensure required fields have appropriate default values
      description: insertTrack.description ?? null,
      duration: insertTrack.duration ?? null,
      bitRate: insertTrack.bitRate ?? null,
      userId: insertTrack.userId ?? null,
      visibility: insertTrack.visibility ?? 'public'
    };
    this.tracks.set(id, track);
    return track;
  }

  async getTrack(id: number): Promise<Track | undefined> {
    return this.tracks.get(id);
  }

  async getAllTracks(): Promise<Track[]> {
    return Array.from(this.tracks.values());
  }

  async getTracksByUser(username: string): Promise<Track[]> {
    return Array.from(this.tracks.values())
      .filter(track => track.artist === username);
  }
  
  async getTracksByUserId(userId: number): Promise<Track[]> {
    return Array.from(this.tracks.values())
      .filter(track => track.userId === userId);
  }

  async deleteTrack(id: number): Promise<boolean> {
    return this.tracks.delete(id);
  }

  async updateTrack(id: number, updateData: Partial<InsertTrack>): Promise<Track | undefined> {
    const existingTrack = this.tracks.get(id);
    if (!existingTrack) return undefined;
    
    const updatedTrack = { ...existingTrack, ...updateData };
    this.tracks.set(id, updatedTrack);
    return updatedTrack;
  }
}

// Export the database storage implementation
export const storage = new DatabaseStorage();
