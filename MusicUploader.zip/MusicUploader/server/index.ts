import dotenv from "dotenv";

// Load environment variables from .env file FIRST, before any other imports
dotenv.config();

// Explicitly set the API keys from the .env file values
process.env.OPENAI_API_KEY = "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";
process.env.STRIPE_SECRET_KEY = "sk_test_51RLXIFRrYerk2U4GyXvZ06RD0EhtCGO2GGwJ75B1GZs2nGYbMb5fVjl6fN1jwTpWTFeyvVp5ENHpKvgqDBH5yAWq003LTT7QjT";
process.env.VITE_STRIPE_PUBLIC_KEY = "pk_test_51RLXIFRrYerk2U4G5sbhDfdGuZ9eb6tzh3zBuXMUMhNp8OD2tmxGeXsZrhMHtsJsinXchNZ3hR2qGPdzYmtE1oxd00B0rTnQkA";

// Log environment variables for debugging
console.log("Environment variables manually set:");
console.log("OPENAI_API_KEY length:", process.env.OPENAI_API_KEY?.length);
console.log("STRIPE_SECRET_KEY length:", process.env.STRIPE_SECRET_KEY?.length);
console.log("VITE_STRIPE_PUBLIC_KEY length:", process.env.VITE_STRIPE_PUBLIC_KEY?.length);

// Import other modules AFTER setting environment variables
import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();
