import OpenAI from "openai";
import fs from "fs";
import path from "path";

// Lazy-initialized OpenAI client to ensure environment variables are fully loaded
class OpenAIClient {
  private static instance: OpenAI | null = null;
  private static initialized = false;
  private static hasApiKey = false;

  public static getInstance(): OpenAI | null {
    if (!this.initialized) {
      this.initialize();
    }
    return this.instance;
  }

  public static hasKey(): boolean {
    if (!this.initialized) {
      this.initialize();
    }
    return this.hasApiKey;
  }

  private static initialize() {
    try {
      const apiKey = process.env.OPENAI_API_KEY;
      
      // Log the API key length for debugging (don't log the actual key)
      console.log("Initializing OpenAI with API key length:", apiKey ? apiKey.length : 0);
      
      if (!apiKey) {
        throw new Error("OPENAI_API_KEY is missing or empty");
      }

      this.hasApiKey = true;
      this.instance = new OpenAI({
        apiKey: apiKey,
      });
      console.log("OpenAI client initialized successfully");
    } catch (error) {
      console.warn("OpenAI client initialization failed:", error);
      console.warn("Running in fallback mode - AI features will use mock data");
      this.instance = null;
      this.hasApiKey = false;
    } finally {
      this.initialized = true;
    }
  }
}

// Alias for simpler access
const openai = () => OpenAIClient.getInstance();
const hasApiKey = () => OpenAIClient.hasKey();

// Create an uploads audio directory for generated audio files
const audioDir = path.join(process.cwd(), "uploads", "audio");
if (!fs.existsSync(audioDir)) {
  fs.mkdirSync(audioDir, { recursive: true });
}

// Function to generate fallback content when OpenAI is not available
function generateFallbackContent(trackInfo: {
  title: string;
  artist: string;
  genre: string;
  description?: string;
}) {
  // Create appropriate hashtags based on genre
  const genreHashtags = {
    pop: "#PopMusic #PopHits #NewPop",
    rock: "#RockMusic #RockAndRoll #NewRock",
    hiphop: "#HipHop #Rap #NewHipHop",
    rnb: "#RnB #RhythmAndBlues #NewRnB",
    electronic: "#Electronic #EDM #NewElectronic",
    jazz: "#JazzMusic #NewJazz #JazzLovers",
    classical: "#ClassicalMusic #Orchestra #NewClassical",
    other: "#NewMusic #MusicLover #FreshTracks"
  };

  const hashtag = genreHashtags[trackInfo.genre.toLowerCase() as keyof typeof genreHashtags] || "#NewMusic #MusicDiscovery";
  
  // Generate a simple caption with track info
  return {
    caption: `Check out this amazing ${trackInfo.genre} track "${trackInfo.title}" by ${trackInfo.artist}! ${trackInfo.description || ''} ${hashtag}`,
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' // Example video URL
  };
}

// Function to generate content based on an audio track
export async function generateContentFromTrack(trackInfo: {
  title: string;
  artist: string;
  genre: string;
  description?: string;
}) {
  // If OpenAI client is not available, use fallback content
  if (!openai() || !hasApiKey()) {
    console.log("Using fallback content generation (no OpenAI API key)");
    return generateFallbackContent(trackInfo);
  }

  try {
    // Create a prompt based on track information
    const prompt = `Generate a creative social media caption for a ${trackInfo.genre} song titled "${trackInfo.title}" by ${trackInfo.artist}. ${
      trackInfo.description ? `The song description is: ${trackInfo.description}` : ''
    }. Make it engaging and shareable with relevant hashtags.`;

    // Generate a caption using OpenAI
    const chatResponse = await openai()!.chat.completions.create({
      model: "gpt-4o", // Using the newest OpenAI model
      messages: [
        {
          role: "system",
          content: "You are a creative social media manager for a music platform. Your job is to create engaging, shareable captions for music content."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      max_tokens: 250,
    });

    const caption = chatResponse.choices[0].message.content || '';

    // For video URL, we would normally handle video generation here
    // For now, we'll return a placeholder
    const videoUrl = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'; // Example video URL

    return {
      caption,
      videoUrl,
    };
  } catch (error) {
    console.error('Error generating content with OpenAI:', error);
    // Use fallback content instead of throwing an error
    return generateFallbackContent(trackInfo);
  }
}

// Function to analyze uploaded song for sentiment, themes, etc.
export async function analyzeAudioContent(trackText: string) {
  // If OpenAI client is not available, use fallback analysis
  if (!openai() || !hasApiKey()) {
    console.log("Using fallback content analysis (no OpenAI API key)");
    return "Fallback analysis: This content appears to have potential appeal to music listeners. Consider enhancing the description with more details about the mood, themes, and instrumentation to better connect with your audience.";
  }

  try {
    const response = await openai()!.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are a music analyst who can identify the key themes, sentiment, and marketable aspects of songs and lyrics."
        },
        {
          role: "user",
          content: `Analyze these song lyrics/description and provide key themes, mood, and audience appeal:\n\n${trackText}`
        }
      ],
      max_tokens: 300,
    });

    return response.choices[0].message.content;
  } catch (error) {
    console.error('Error analyzing content with OpenAI:', error);
    return "Error in AI analysis. Please try again later or provide more detailed content to analyze.";
  }
}

// Function to generate audio narration for track descriptions
export async function generateAudioNarration(trackInfo: {
  title: string;
  artist: string;
  genre: string;
  description?: string;
}) {
  // If OpenAI client is not available, return error
  if (!openai() || !hasApiKey()) {
    console.log("Audio narration not available (no OpenAI API key)");
    return null;
  }

  try {
    // Create a script for narration
    const script = `Introducing "${trackInfo.title}" by ${trackInfo.artist}. This ${trackInfo.genre} track ${
      trackInfo.description ? `is described as: ${trackInfo.description}` : 'is a fresh new release'
    }. Give it a listen and share with your friends!`;

    // Generate audio using OpenAI
    const response = await openai()!.chat.completions.create({
      model: "gpt-4o-audio-preview",
      modalities: ["text", "audio"],
      audio: { voice: "alloy", format: "wav" },
      messages: [
        {
          role: "user",
          content: script
        }
      ],
      store: true,
    });

    // Generate a unique filename
    const filename = `narration-${Date.now()}.wav`;
    const filePath = path.join(audioDir, filename);

    // Write audio data to a file
    if (response.choices[0].message.audio?.data) {
      fs.writeFileSync(
        filePath,
        Buffer.from(response.choices[0].message.audio.data, 'base64')
      );

      // Return the path to the audio file
      return {
        narrationText: response.choices[0].message.content,
        audioUrl: `/uploads/audio/${filename}`
      };
    } else {
      throw new Error('No audio data received from OpenAI');
    }
  } catch (error) {
    console.error('Error generating audio narration with OpenAI:', error);
    return null;
  }
}

// Function to transcribe and analyze audio content
export async function transcribeAudioContent(audioFilePath: string) {
  // If OpenAI client is not available, return error
  if (!openai() || !hasApiKey()) {
    console.log("Audio transcription not available (no OpenAI API key)");
    return null;
  }

  try {
    // Read the audio file and convert to base64
    const audioData = fs.readFileSync(audioFilePath);
    const base64Audio = audioData.toString('base64');

    // Get the file format (extension)
    const fileFormat = path.extname(audioFilePath).replace('.', '');
    
    // Due to type definition issues, we need to use any for the audio API
    // The official OpenAI API supports input_audio but the TypeScript types may not be updated
    const response = await (openai()! as any).chat.completions.create({
      model: "gpt-4o-audio-preview",
      modalities: ["text", "audio"],
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: "Transcribe this audio and analyze its musical content. What are the themes, mood, and key musical elements?" },
            { type: "input_audio", input_audio: { data: base64Audio, format: fileFormat }}
          ]
        }
      ],
      store: true,
    });

    // Return the transcription and analysis
    return {
      transcription: response.choices[0].message.content,
    };
  } catch (error) {
    console.error('Error transcribing audio with OpenAI:', error);
    return null;
  }
}