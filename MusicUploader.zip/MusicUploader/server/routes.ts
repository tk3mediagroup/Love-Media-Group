import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import express from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { SUPPORTED_AUDIO_FORMATS, MAX_FILE_SIZE, insertTrackSchema, insertUserSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import ConnectPgSimple from "connect-pg-simple";
import { pool } from "./db";
import Stripe from "stripe";
import { 
  generateContentFromTrack, 
  analyzeAudioContent, 
  generateAudioNarration,
  transcribeAudioContent
} from "./openai";

// Create upload directory if it doesn't exist
const uploadDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Configure multer for file uploads
const fileStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  },
});

const upload = multer({
  storage: fileStorage,
  limits: {
    fileSize: MAX_FILE_SIZE, // 50MB max file size
  },
  fileFilter: (req, file, cb) => {
    if (SUPPORTED_AUDIO_FORMATS.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Unsupported file format. Please upload MP3, WAV, FLAC or OGG files only."));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize Stripe
  let stripe: Stripe | undefined;
  if (process.env.STRIPE_SECRET_KEY) {
    stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    console.log("Stripe initialized successfully");
  } else {
    console.log("Stripe not initialized. STRIPE_SECRET_KEY is missing.");
  }
  // Configure session
  const PgSession = ConnectPgSimple(session);
  app.use(
    session({
      store: new PgSession({
        pool,
        tableName: "user_sessions",
        createTableIfMissing: true,
      }),
      secret: process.env.SESSION_SECRET || "love-media-group-secret",
      resave: false,
      saveUninitialized: false,
      cookie: {
        maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
        secure: process.env.NODE_ENV === "production",
      },
    })
  );

  // Configure passport
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "Incorrect username" });
        }
        
        // In a real app, you would compare hashed passwords
        if (user.password !== password) {
          return done(null, false, { message: "Incorrect password" });
        }
        
        return done(null, user);
      } catch (err) {
        return done(err);
      }
    })
  );

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  app.use(passport.initialize());
  app.use(passport.session());

  // Authentication middleware
  const isAuthenticated = (req: Request, res: Response, next: NextFunction) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Unauthorized" });
  };

  // Serve uploaded files
  app.use("/uploads", express.static(uploadDir));

  // Authentication routes
  app.post("/api/register", async (req, res) => {
    try {
      // Validate user data
      const parsedData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(parsedData.username);
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      
      // Create user
      const user = await storage.createUser(parsedData);
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      // Log in the user
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ message: "Error logging in after registration" });
        }
        return res.status(201).json(userWithoutPassword);
      });
    } catch (error) {
      console.error("Registration error:", error);
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err, user, info) => {
      if (err) {
        return next(err);
      }
      if (!user) {
        return res.status(401).json({ message: info.message });
      }
      req.login(user, (err) => {
        if (err) {
          return next(err);
        }
        // Remove password from response
        const { password, ...userWithoutPassword } = user;
        return res.json(userWithoutPassword);
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req, res) => {
    req.logout(() => {
      res.status(200).json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/user", (req, res) => {
    if (req.user) {
      // Remove password from response
      const { password, ...userWithoutPassword } = req.user as any;
      return res.json(userWithoutPassword);
    }
    res.status(401).json({ message: "Not authenticated" });
  });

  // API Routes
  app.post("/api/upload", isAuthenticated, upload.single("audioFile"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const file = req.file;
      const trackData = req.body;

      // Validate track data
      try {
        const parsedData = insertTrackSchema.parse({
          ...trackData,
          fileName: file.filename,
          fileSize: file.size,
          fileType: file.mimetype,
          userId: (req.user as any)?.id, // Add user ID to track
          visibility: trackData.visibility || 'public',
        });

        // Store track in database
        const savedTrack = await storage.createTrack(parsedData);
        res.status(201).json(savedTrack);
      } catch (error) {
        // Delete the uploaded file if validation fails
        fs.unlinkSync(file.path);
        
        if (error instanceof ZodError) {
          const validationError = fromZodError(error);
          return res.status(400).json({ message: validationError.message });
        }
        throw error;
      }
    } catch (error) {
      console.error("Upload error:", error);
      res.status(500).json({ message: error instanceof Error ? error.message : "Internal server error" });
    }
  });

  // Get all tracks
  app.get("/api/tracks", async (req, res) => {
    try {
      const tracks = await storage.getAllTracks();
      res.json(tracks);
    } catch (error) {
      console.error("Error fetching tracks:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Get user's tracks
  app.get("/api/my-tracks", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.id;
      if (!userId) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      // Use the storage interface to get tracks by user ID
      const tracks = await storage.getTracksByUserId(userId);
      res.json(tracks);
    } catch (error) {
      console.error("Error fetching user tracks:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get a specific track
  app.get("/api/tracks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid track ID" });
      }

      const track = await storage.getTrack(id);
      if (!track) {
        return res.status(404).json({ message: "Track not found" });
      }

      res.json(track);
    } catch (error) {
      console.error("Error fetching track:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Delete a track
  app.delete("/api/tracks/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid track ID" });
      }

      const track = await storage.getTrack(id);
      if (!track) {
        return res.status(404).json({ message: "Track not found" });
      }
      
      // Check if user owns the track
      const userId = (req.user as any)?.id;
      if (track.userId && track.userId !== userId) {
        return res.status(403).json({ message: "You don't have permission to delete this track" });
      }

      // Delete the file
      const filePath = path.join(uploadDir, track.fileName);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }

      // Delete from storage
      await storage.deleteTrack(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting track:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Update a track
  app.patch("/api/tracks/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid track ID" });
      }

      const track = await storage.getTrack(id);
      if (!track) {
        return res.status(404).json({ message: "Track not found" });
      }
      
      // Check if user owns the track
      const userId = (req.user as any)?.id;
      if (track.userId && track.userId !== userId) {
        return res.status(403).json({ message: "You don't have permission to update this track" });
      }

      const updatedTrack = await storage.updateTrack(id, req.body);
      res.json(updatedTrack);
    } catch (error) {
      console.error("Error updating track:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Generate content for a track using AI
  app.post("/api/tracks/:id/generate-content", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid track ID" });
      }

      const track = await storage.getTrack(id);
      if (!track) {
        return res.status(404).json({ message: "Track not found" });
      }
      
      // Check if user owns the track
      const userId = (req.user as any)?.id;
      if (track.userId && track.userId !== userId) {
        return res.status(403).json({ message: "You don't have permission to generate content for this track" });
      }

      // Generate content based on track information
      const generatedContent = await generateContentFromTrack({
        title: track.title,
        artist: track.artist,
        genre: track.genre,
        description: track.description || undefined
      });

      res.json(generatedContent);
    } catch (error) {
      console.error("Error generating content:", error);
      // Check if it's an API key error
      const errorMessage = error instanceof Error ? error.message : "Internal server error";
      if (errorMessage.includes("API key") || errorMessage.includes("authentication")) {
        return res.status(500).json({ 
          message: "OpenAI API key error. Please check your API key configuration.",
          error: errorMessage
        });
      }
      res.status(500).json({ message: errorMessage });
    }
  });
  
  // Generate audio narration for a track
  app.post("/api/tracks/:id/generate-narration", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid track ID" });
      }

      const track = await storage.getTrack(id);
      if (!track) {
        return res.status(404).json({ message: "Track not found" });
      }
      
      // Check if user owns the track
      const userId = (req.user as any)?.id;
      if (track.userId && track.userId !== userId) {
        return res.status(403).json({ message: "You don't have permission to generate narration for this track" });
      }

      // Generate audio narration for the track
      const narration = await generateAudioNarration({
        title: track.title,
        artist: track.artist,
        genre: track.genre,
        description: track.description || undefined
      });

      if (!narration) {
        return res.status(500).json({ 
          message: "Failed to generate audio narration. OpenAI API key may be missing or invalid."
        });
      }

      res.json(narration);
    } catch (error) {
      console.error("Error generating audio narration:", error);
      // Check if it's an API key error
      const errorMessage = error instanceof Error ? error.message : "Internal server error";
      if (errorMessage.includes("API key") || errorMessage.includes("authentication")) {
        return res.status(500).json({ 
          message: "OpenAI API key error. Please check your API key configuration.",
          error: errorMessage
        });
      }
      res.status(500).json({ message: errorMessage });
    }
  });

  // Analyze text content (lyrics, description) for a track
  app.post("/api/analyze-content", isAuthenticated, async (req, res) => {
    try {
      const { text } = req.body;
      
      if (!text || typeof text !== 'string' || text.trim() === '') {
        return res.status(400).json({ message: "Text content is required" });
      }

      // Analyze the text content
      const analysis = await analyzeAudioContent(text);
      res.json({ analysis });
    } catch (error) {
      console.error("Error analyzing content:", error);
      // Check if it's an API key error
      const errorMessage = error instanceof Error ? error.message : "Internal server error";
      if (errorMessage.includes("API key") || errorMessage.includes("authentication")) {
        return res.status(500).json({ 
          message: "OpenAI API key error. Please check your API key configuration.",
          error: errorMessage
        });
      }
      res.status(500).json({ message: errorMessage });
    }
  });
  
  // Transcribe and analyze audio content for a track
  app.post("/api/tracks/:id/transcribe", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid track ID" });
      }

      const track = await storage.getTrack(id);
      if (!track) {
        return res.status(404).json({ message: "Track not found" });
      }
      
      // Check if user owns the track
      const userId = (req.user as any)?.id;
      if (track.userId && track.userId !== userId) {
        return res.status(403).json({ message: "You don't have permission to transcribe this track" });
      }

      // Get the full path to the audio file
      const audioFilePath = path.join(uploadDir, track.fileName);
      if (!fs.existsSync(audioFilePath)) {
        return res.status(404).json({ message: "Audio file not found" });
      }

      // Transcribe the audio content
      const transcription = await transcribeAudioContent(audioFilePath);
      
      if (!transcription) {
        return res.status(500).json({ 
          message: "Failed to transcribe audio. OpenAI API key may be missing or invalid."
        });
      }

      res.json(transcription);
    } catch (error) {
      console.error("Error transcribing audio:", error);
      // Check if it's an API key error
      const errorMessage = error instanceof Error ? error.message : "Internal server error";
      if (errorMessage.includes("API key") || errorMessage.includes("authentication")) {
        return res.status(500).json({ 
          message: "OpenAI API key error. Please check your API key configuration.",
          error: errorMessage
        });
      }
      res.status(500).json({ message: errorMessage });
    }
  });
  
  // Payment processing routes with Stripe
  app.post("/api/create-checkout-session", isAuthenticated, async (req, res) => {
    try {
      if (!stripe) {
        return res.status(500).json({ 
          message: "Stripe is not initialized. Please check your environment variables."
        });
      }
      
      const { productId } = req.body;
      
      // Define product information based on the productId
      let productInfo;
      switch (productId) {
        case 'premium-content-generation':
          productInfo = {
            name: 'Premium Content Generation',
            description: 'Unlock advanced AI-powered content generation features',
            amount: 1999 // $19.99 in cents
          };
          break;
        case 'audio-transcription-pack':
          productInfo = {
            name: 'Audio Transcription Pack',
            description: '10 audio tracks transcription and analysis',
            amount: 999 // $9.99 in cents
          };
          break;
        default:
          return res.status(400).json({ message: "Invalid product ID" });
      }
      
      // Create a Stripe checkout session
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [
          {
            price_data: {
              currency: 'usd',
              product_data: {
                name: productInfo.name,
                description: productInfo.description
              },
              unit_amount: productInfo.amount,
            },
            quantity: 1,
          },
        ],
        mode: 'payment',
        success_url: `${req.protocol}://${req.get('host')}/payment/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${req.protocol}://${req.get('host')}/payment/cancel`,
        metadata: {
          userId: (req.user as any)?.id,
          productId
        },
      });
      
      res.json({ url: session.url });
    } catch (error) {
      console.error("Error creating checkout session:", error);
      res.status(500).json({ 
        message: "Failed to create checkout session",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Stripe webhook endpoint for handling post-payment events
  app.post("/api/webhook", express.raw({ type: 'application/json' }), async (req, res) => {
    if (!stripe) {
      return res.status(500).send('Stripe is not initialized');
    }

    const sig = req.headers['stripe-signature'];
    if (!sig) {
      return res.status(400).send('Missing stripe-signature header');
    }

    // This is your Stripe webhook secret for testing your endpoint locally
    const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;
    if (!endpointSecret) {
      return res.status(500).send('Webhook secret is not configured');
    }

    let event;

    try {
      event = stripe.webhooks.constructEvent(
        req.body,
        sig,
        endpointSecret
      );
    } catch (err) {
      console.error(`Webhook Error: ${err.message}`);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    // Handle the checkout.session.completed event
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      
      // Retrieve the user ID and product ID from metadata
      const userId = session.metadata?.userId;
      const productId = session.metadata?.productId;
      
      if (userId && productId) {
        try {
          // In a real application, you would update the user's permissions
          // based on the purchased product
          console.log(`Payment successful for user ${userId}, product ${productId}`);
          
          // Update user information in the database
          // Here you would add logic to activate premium features for the user
          
          // For example:
          // await storage.updateUserSubscription(userId, {
          //   hasPremium: true,
          //   productId: productId,
          //   expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
          // });
        } catch (error) {
          console.error('Error processing successful payment:', error);
        }
      }
    }

    // Return a 200 response to acknowledge receipt of the event
    res.send();
  });

  const httpServer = createServer(app);
  return httpServer;
}
